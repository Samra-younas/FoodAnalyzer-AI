package com.example.meal_mingle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
